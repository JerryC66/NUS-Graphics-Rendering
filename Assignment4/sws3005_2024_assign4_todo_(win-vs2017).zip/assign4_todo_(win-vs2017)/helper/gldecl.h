#ifndef _GL_DECL_
#define _GL_DECL_

#ifdef __APPLE__
#include <OpenGL/gl3.h>
#else
#include <GL/glew.h>
#endif

#define GLM_FORCE_RADIANS

#endif
